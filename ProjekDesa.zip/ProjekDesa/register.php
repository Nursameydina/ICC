<?php
session_start();

// Koneksi ke database
$conn = new mysqli("id", "username", "password_hash", "users");


// Memeriksa koneksi
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Ambil data dari formulir registrasi
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Enkripsi password menggunakan bcrypt

    // Query untuk memeriksa apakah username sudah digunakan
    $checkQuery = "SELECT * FROM users WHERE username='$username'";
    $checkResult = $conn->query($checkQuery);

    if ($checkResult->num_rows > 0) {
        // Username sudah digunakan
        echo "Username sudah digunakan. Silakan pilih username lain.";
    } else {
        // Query untuk menambahkan pengguna baru ke database
        $insertQuery = "INSERT INTO users (username, password_hash) VALUES ('$username', '$password')";
        if ($conn->query($insertQuery) === TRUE) {
            // Registrasi berhasil
            echo "Registrasi berhasil. Silakan login <a href='login.html'>di sini</a>.";
        } else {
            // Registrasi gagal
            echo "Error: " . $insertQuery . "<br>" . $conn->error;
        }
    }
}

// Tutup koneksi database
$conn->close();
?>
