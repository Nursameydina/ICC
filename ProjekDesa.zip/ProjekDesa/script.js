function login() {
    var username = document.getElementById("username").value;
    var password = document.getElementById("password").value;

    // Contoh sederhana validasi login
    if (username === "admin" && password === "admin") {
        // Login berhasil, tampilkan informasi desa
        document.getElementById("loginForm").style.display = "none";
        document.getElementById("infoContainer").style.display = "block";

        // Tambahkan informasi desa di sini
        var infoContainer = document.getElementById("infoContainer");
        var desaInfo = document.createElement("p");
        desaInfo.textContent = "Selamat datang di website Desa! Ini adalah contoh informasi desa.";
        infoContainer.appendChild(desaInfo);
    } else {
        alert("Login gagal. Coba lagi.");
    }
}

document.addEventListener("DOMContentLoaded", function () {
    const form = document.getElementById("village-form");
    const villagesList = document.getElementById("villages");
    
    form.addEventListener("submit", function (e) {
        e.preventDefault();
        
        const name = document.getElementById("name").value;
        const population = document.getElementById("population").value;
        
        if (name && population) {
            const village = {
                name,
                population
            };
            
            addVillage(village);
            clearForm();
        }
    });
    
    villagesList.addEventListener("click", function (e) {
        if (e.target.tagName === "BUTTON") {
            if (e.target.classList.contains("delete")) {
                deleteVillage(e.target.parentNode.dataset.id);
            } else if (e.target.classList.contains("edit")) {
                editVillage(e.target.parentNode);
            }
        }
    });
    
    function addVillage(village) {
        const listItem = document.createElement("li");
        listItem.dataset.id = new Date().getTime();
        listItem.innerHTML = `
            <span>${village.name} (Jumlah Penduduk: ${village.population})</span>
            <button class="edit">Edit</button>
            <button class="delete">Hapus</button>
        `;
        villagesList.appendChild(listItem);
    }
    
    function clearForm() {
        document.getElementById("name").value = "";
        document.getElementById("population").value = "";
    }
    
    function deleteVillage(id) {
        const listItem = document.querySelector(`li[data-id="${id}"]`);
        listItem.remove();
    }
    
    function editVillage(listItem) {
        const name = listItem.querySelector("span").textContent.split(" (Jumlah Penduduk: ")[0];
        const population = listItem.querySelector("span").textContent.split(" (Jumlah Penduduk: ")[1].replace(")", "");
        
        document.getElementById("name").value = name;
        document.getElementById("population").value = population;
        
        listItem.remove();
    }
});
