<?php
session_start();

// Koneksi ke database
$conn = new mysqli("id", "username", "password_hash", "users");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Ambil data dari formulir login
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Query untuk mencari pengguna dengan username
    $query = "SELECT * FROM users WHERE username='$username'";
    $result = $conn->query($query);

    // Jika hasil query mengembalikan baris
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();

        // Verifikasi kata sandi menggunakan password_verify()
        if (password_verify($password, $row['password_hash'])) {
            // Login berhasil
            $_SESSION['username'] = $username;
            header("Location: index.html");
            exit(); // Pastikan untuk keluar dari skrip setelah mengarahkan
        } else {
            // Login gagal, kata sandi tidak cocok
            echo "Login failed. Check your username or password.";
        }
    } else {
        // Login gagal, pengguna tidak ditemukan
        echo "Login failed. Check your username or password.";
    }
}

// Tutup koneksi database
$conn->close();
?>
